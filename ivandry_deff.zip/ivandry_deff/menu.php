<div class="row">
		<div class="head_banner">
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-3" >
				<div ><a href="http:#" class=""><img class="head_logo" src="ivandry/img/logo.png" alt="logo" /></a></div>
			</div>
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6" >
                            <?php include('navbar.php'); ?>
			</div>
			<div class="col-xs-12 col-sm-12 col-md-12 col-lg-3" >
				<form class="navbar-form pull-left">
					<input type="text" class="input-sm form-control" placeholder="Recherche">
						<button type="submit" class="btn btn-primary btn-sm" style="width:20px;height:25px;border:2px solid #BED13E;background-image:url('ivandry/img/loupe.png');">
						</button>
				</form>
			</div>
		</div>
	</div>



