<nav class="navbar navbar-default navbar-static">
	<div class="navbar-header">
		<button class="navbar-toggle" type="button" data-toggle="collapse" data-target=".js-navbar-collapse">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</button>
		<a class="navbar-brand" href="#"></a>
	
	
	
	<div class="collapse navbar-collapse js-navbar-collapse">
		<ul class="nav navbar-nav">
                    
                    <li class="dropdown dropdown-large">
				<a href="#" class="dropdown-toggle" data-toggle="dropdown">Dropdown <b class="caret"></b></a>
				
				<ul class="dropdown-menu dropdown-menu-large row">
					<li class="col-sm-2">
						<ul>
							<li class="dropdown-header">BIRAO</li>
						</ul>
					</li>
					<li class="col-sm-2">
						<ul>
							<li class="dropdown-header">SAMPANA</li>
                                                        <div style="text-align: left; font-weight: normal; padding-left: 30px">
                                                        <li><a href="#"> STK</a></li>
							<li><a href="#"> SAFIF</a></li>
							<li><a href="#"> SA</a></li>
							<li><a href="#"> DORKASY</a></li>
							<li><a href="#"> SVM</a></li>
                                                        </div>
						</ul>
					</li>
					<li class="col-sm-2">
						<ul>
							<li class="dropdown-header">FIKAMBANANA</li>
                                                        <div style="text-align: left; font-weight: normal; padding-left: 30px">
                                                        <li><a href="#"> STK</a></li>
							<li><a href="#"> SAFIF</a></li>
							<li><a href="#"> SA</a></li>
							<li><a href="#"> DORKASY</a></li>
							<li><a href="#"> SVM</a></li>
                                                        </div>
						</ul>
					</li>
					<li class="col-sm-2">
						<ul>
							<li class="dropdown-header">VAOMIERA</li>
                                                        <div style="text-align: left; font-weight: normal; padding-left: 30px">
                                                        <li><a href="#"> STK</a></li>
							<li><a href="#"> SAFIF</a></li>
							<li><a href="#"> SA</a></li>
							<li><a href="#"> DORKASY</a></li>
							<li><a href="#"> SVM</a></li>
                                                        </div>
						</ul>
					</li>
                                        <li class="col-sm-2">
						<ul>
							<li class="dropdown-header">FIKAMBANANA</li>
                                                        <div style="text-align: left; font-weight: normal; padding-left: 30px">
                                                        <li><a href="#"> STK</a></li>
							<li><a href="#"> SAFIF</a></li>

                                                        </div>
						</ul>
					</li>
				</ul>
				
			</li>
                        <li class="dropdown dropdown-large">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Dropdown <b class="caret"></b></a>
                        <ul class="dropdown-menu dropdown-menu-large row">
                            <li class="col-sm-2">
                                    <ul>
                                            <li class="dropdown-header">BIRAO</li>
                                    </ul>
                            </li>
                        </ul>
                    </li>
                    <li class="dropdown dropdown-large">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Dropdown <b class="caret"></b></a></li>                   
                    <li class="dropdown dropdown-large">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Dropdown <b class="caret"></b></a></li>
                    <li class="dropdown dropdown-large">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Dropdown <b class="caret"></b></a></li>
                    <li class="dropdown dropdown-large">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown">Dropdown <b class="caret"></b></a></li>                    
		</ul>
		
	</div><!-- /.nav-collapse -->
	</div>
</nav>
